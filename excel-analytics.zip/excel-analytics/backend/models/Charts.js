const mongoose = require('mongoose');

const ChartSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  title: String,
  chartType: String,
  labels: [String],
  values: [Number],
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Chart', ChartSchema);
