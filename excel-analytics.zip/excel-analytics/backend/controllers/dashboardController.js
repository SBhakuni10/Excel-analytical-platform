const Upload = require('../models/Excel');

// GET: Fetch dashboard stats for authenticated user
exports.getDashboardStats = async (req, res) => {
  try {
    const uploads = await Upload.find({ uploadedBy: req.user.id }).sort({ createdAt: -1 });
    res.status(200).json({
      success: true,
      totalUploads: uploads.length,
      uploads,
    });
  } catch (error) {
    console.error('Dashboard error:', error.message);
    res.status(500).json({ success: false, error: 'Failed to load dashboard data' });
  }
};

// POST: Add a new upload (used when submitting JSON manually, not file)
exports.addUpload = async (req, res) => {
  try {
    const { filename, data } = req.body;

    if (!filename || !Array.isArray(data)) {
      return res.status(400).json({ success: false, error: 'Invalid data format' });
    }

    const upload = new Upload({
      filename,
      data,
      uploadedBy: req.user.id,
    });

    await upload.save();
    res.status(201).json({ success: true, message: 'Upload added successfully', upload });
  } catch (error) {
    console.error('Upload error:', error.message);
    res.status(500).json({ success: false, error: 'Upload failed' });
  }
};

// DELETE: Remove a specific upload
exports.deleteUpload = async (req, res) => {
  try {
    const { id } = req.params;
    const upload = await Upload.findOneAndDelete({ _id: id, uploadedBy: req.user.id });

    if (!upload) {
      return res.status(404).json({ success: false, error: 'Upload not found or not authorized' });
    }

    res.status(200).json({ success: true, message: 'Upload deleted successfully' });
  } catch (error) {
    console.error('Delete error:', error.message);
    res.status(500).json({ success: false, error: 'Delete failed' });
  }
};
