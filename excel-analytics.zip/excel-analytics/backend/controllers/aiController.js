const axios = require('axios');
require('dotenv').config();

exports.chatWithOpenAI = async (req, res) => {
  const { model, messages } = req.body;

  // Validate request body
  if (!model || !messages || !Array.isArray(messages)) {
    return res.status(400).json({
      error: 'Invalid request. Please provide a "model" and an array of "messages".',
    });
  }

  try {
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model, // e.g., 'gpt-3.5-turbo'
        messages, // e.g., [{ role: "user", content: "Hello!" }]
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`, // ensure .env key is present
        },
      }
    );

    res.status(200).json(response.data);
  } catch (error) {
    console.error('OpenAI API error:', error?.response?.data || error.message);

    // Handle quota error
    if (error.response?.status === 429) {
      return res.status(429).json({
        error: 'You have exceeded your OpenAI API quota. Please upgrade your plan or wait before retrying.',
      });
    }

    res.status(error.response?.status || 500).json({
      error: error.response?.data || 'An unexpected error occurred.',
    });
  }
};
