const express = require('express');
const multer = require('multer');
const xlsx = require('xlsx');
const fs = require('fs');
const path = require('path');
const auth = require('../middleware/auth');  // make sure auth exports a function
const Excel = require('../models/Excel');

const router = express.Router();

// Multer setup for file upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname)),
});
const upload = multer({ storage });

// POST /upload route
router.post('/upload', auth, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const filePath = path.join(__dirname, '..', 'uploads', req.file.filename);
    const workbook = xlsx.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const jsonData = xlsx.utils.sheet_to_json(sheet);

    const newRecord = new Excel({
      user: req.user.id,          // assuming auth sets req.user
      fileName: req.file.originalname,
      data: jsonData,
    });
    await newRecord.save();

    fs.unlinkSync(filePath);

    res.status(201).json({
      message: 'Excel file uploaded and data saved successfully',
      recordId: newRecord._id,
      rowCount: jsonData.length,
    });
  } catch (err) {
    console.error('Upload error:', err);
    res.status(500).json({ error: 'Server error while uploading Excel' });
  }
});

// GET record by id route
router.get('/record', auth, async (req, res) => {
  try {
    const record = await Excel.findById(req.params.id);
    if (!record) {
      return res.status(404).json({ error: 'Record not found' });
    }
    res.status(200).json({
      message: 'Record fetched successfully',
      data: record.data,
    });
  } catch (err) {
    console.error('Fetch error:', err);
    res.status(500).json({ error: 'Failed to fetch uploads' });
  }
});

module.exports = router;
