const express = require('express');
const router = express.Router();
const { chatWithOpenAI } = require('../controllers/aiController');

router.post('/chat', chatWithOpenAI);

module.exports = router;
