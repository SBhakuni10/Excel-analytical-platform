const express = require('express');
const Charts = require('../models/Charts'); // 'Charts' is the correct import
const auth = require('../middleware/auth');

const router = express.Router();

router.get('/charts', auth, async (req, res) => {
  try {
    const charts = await Charts.find({ user: req.user.id }).sort({ createdAt: -1 });
    res.status(200).json({ success: true, charts });
  } catch (err) {
    console.error('GET /charts error:', err);
    res.status(500).json({ success: false, error: 'Failed to fetch charts' });
  }
});

router.post('/save', auth, async (req, res) => {
  try {
    const { title, chartType, labels, values } = req.body;

    const chart = new Charts({ user: req.user.id, title, chartType, labels, values });
    await chart.save();

    res.status(201).json({ message: 'Chart saved' });
  } catch (err) {
    console.error('POST /save error:', err);
    res.status(500).json({ message: 'Failed to save chart' });
  }
});

module.exports = router;
