const express = require('express');
const {
  getDashboardStats,
  addUpload,
  deleteUpload,
} = require('../controllers/dashboardController');
const auth = require('../middleware/auth');  // your auth middleware

const router = express.Router();

// GET dashboard data
router.get('/', auth, getDashboardStats);

// POST new manual upload (optional - for testing or JSON insert)
router.post('/', auth, addUpload);

// DELETE an upload by ID
router.delete('/:id', auth, deleteUpload);

module.exports = router;
