// ✅ FILE: src/utils/exportChart.js
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

/**
 * Export the given DOM element as PNG.
 * @param {HTMLElement} element - DOM node (chart wrapper div).
 */
export const downloadAsPNG = async (element) => {
  if (!element) return alert('Chart element not found.');
  try {
    const canvas = await html2canvas(element, { useCORS: true, scale: 2 });
    const link = document.createElement('a');
    link.download = 'chart.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
  } catch (error) {
    console.error('❌ PNG export failed:', error);
    alert('Failed to export chart as PNG.');
  }
};

/**
 * Export the given DOM element as PDF.
 * @param {HTMLElement} element - DOM node (chart wrapper div).
 */
export const downloadAsPDF = async (element) => {
  if (!element) return alert('Chart element not found.');
  try {
    const canvas = await html2canvas(element, { useCORS: true, scale: 2 });
    const imgData = canvas.toDataURL('image/png');

    const pdf = new jsPDF({
      orientation: 'landscape',
      unit: 'px',
      format: [canvas.width, canvas.height],
    });

    pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
    pdf.save('chart.pdf');
  } catch (error) {
    console.error('❌ PDF export failed:', error);
    alert('Failed to export chart as PDF.');
  }
};
