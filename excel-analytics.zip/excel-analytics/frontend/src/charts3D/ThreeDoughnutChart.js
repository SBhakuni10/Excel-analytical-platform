import React from 'react';
import { Canvas } from '@react-three/fiber';
import * as THREE from 'three';

function ThreeDoughnutChart({ chartType = 'Doughnut', labels = [], values = [] }) {
  const colors = ['#3f51b5', '#e91e63', '#4caf50', '#ff9800', '#9c27b0'];

  const total = values.reduce((acc, val) => acc + val, 0);

  // Create pie segments as meshes with circular arc geometry
  const pieSegments = values.map((val, i) => {
    const startAngle = (values.slice(0, i).reduce((a, v) => a + v, 0) / total) * Math.PI * 2;
    const endAngle = ((values.slice(0, i + 1).reduce((a, v) => a + v, 0)) / total) * Math.PI * 2;

    const shape = new THREE.Shape();
    shape.moveTo(0, 0);
    shape.absarc(0, 0, 3, startAngle, endAngle, false);
    shape.lineTo(0, 0);

    const geometry = new THREE.ExtrudeGeometry(shape, {
      depth: 1,
      bevelEnabled: false
    });

    const midAngle = (startAngle + endAngle) / 2;
    const x = Math.cos(midAngle) * 0.5;
    const y = Math.sin(midAngle) * 0.5;

    return (
      <mesh key={i} position={[0, 0, 0]}>
        <primitive object={geometry} attach="geometry" />
        <meshStandardMaterial color={colors[i % colors.length]} />
      </mesh>
    );
  });

  return (
    <div style={{ width: '100%', height: '400px' }}>
      <Canvas
        camera={{ position: [0, 0, 10] }}
        style={{ background: '#f0f0f0', width: '100%', height: '100%' }}
      >
        <ambientLight />
        <pointLight position={[10, 10, 10]} />

        {chartType === 'Doughnut' && (
          <mesh>
            <torusGeometry args={[2, 0.7, 16, 100]} />
            <meshStandardMaterial color={colors[0]} />
          </mesh>
        )}

        {chartType === 'Bar' &&
          values.map((val, i) => (
            <mesh key={i} position={[i * 2 - (values.length - 1), val / 2, 0]}>
              <boxGeometry args={[1, val, 1]} />
              <meshStandardMaterial color={colors[i % colors.length]} />
            </mesh>
          ))}

        {chartType === 'Pie' && pieSegments}
      </Canvas>
    </div>
  );
}

export default ThreeDoughnutChart;
