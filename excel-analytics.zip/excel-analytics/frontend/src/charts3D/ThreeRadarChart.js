import React from 'react';
import { Canvas } from '@react-three/fiber';

function ThreeRadarChart({ labels, values }) {
  const radius = values.map((v) => v / 10);
  return (
    <Canvas camera={{ position: [0, 0, 10] }}>
      <ambientLight />
      {radius.map((r, i) => (
        <mesh key={i} position={[Math.cos(i) * r, Math.sin(i) * r, 0]}>
          <sphereGeometry args={[0.2, 16, 16]} />
          <meshStandardMaterial color={'#673ab7'} />
        </mesh>
      ))}
    </Canvas>
  );
}
export default ThreeRadarChart;
