// ✅ FILE: src/charts3D/ThreeLineChart.js
import React from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Line } from '@react-three/drei';

function ThreeLineChart({ labels, values }) {
  const points = values.map((y, i) => [i, y, 0]);

  return (
    <Canvas camera={{ position: [0, 0, 10], fov: 50 }}>
      <ambientLight />
      <pointLight position={[10, 10, 10]} />
      <Line points={points} color="blue" lineWidth={2} />
      <OrbitControls />
    </Canvas>
  );
}

export default ThreeLineChart;
