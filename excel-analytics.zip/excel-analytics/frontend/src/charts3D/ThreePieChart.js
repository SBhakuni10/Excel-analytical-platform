import React, { useMemo } from 'react';
import * as THREE from 'three';
import { Canvas } from '@react-three/fiber';

function PieSegment({ angleStart, angleEnd, radius, color, index }) {
  const geometry = useMemo(() => {
    const shape = new THREE.Shape();
    shape.moveTo(0, 0);
    shape.absarc(0, 0, radius, angleStart, angleEnd, false);
    shape.lineTo(0, 0);
    return new THREE.ShapeGeometry(shape);
  }, [angleStart, angleEnd, radius]);

  return (
    <mesh geometry={geometry} position={[0, 0, index * 0.01]}>
      <meshStandardMaterial color={color} />
    </mesh>
  );
}

function ThreePieChart({ values }) {
  const total = values.reduce((a, b) => a + b, 0);
  const radius = 3;
  const colors = ['red', 'green', 'blue', 'orange', 'purple', 'yellow'];

  if (!Array.isArray(values) || values.length === 0 || total === 0) {
    return <div className="text-red-600 p-4">⚠️ Invalid or empty data for 3D Pie Chart</div>;
  }

  let currentAngle = 0;
  const segments = values.map((val, i) => {
    const angle = (val / total) * Math.PI * 2;
    const segment = (
      <PieSegment
        key={i}
        index={i}
        angleStart={currentAngle}
        angleEnd={currentAngle + angle}
        radius={radius}
        color={colors[i % colors.length]}
      />
    );
    currentAngle += angle;
    return segment;
  });

  return (
    <div style={{ width: '100%', height: '400px' }}>
      <Canvas camera={{ position: [0, 0, 10] }}>
        <ambientLight />
        <pointLight position={[10, 10, 10]} />
        {segments}
      </Canvas>
    </div>
  );
}

export default ThreePieChart;
