import React from 'react';
import { Canvas } from '@react-three/fiber';

function ThreeBarChart({ labels, values }) {
  return (
    <Canvas camera={{ position: [0, 0, 10] }}>
      <ambientLight />
      <pointLight position={[10, 10, 10]} />
      {values.map((val, idx) => (
        <mesh key={idx} position={[idx * 2 - values.length, val / 20, 0]}>
          <boxGeometry args={[1, val / 10, 1]} />
          <meshStandardMaterial color={'#4caf50'} />
        </mesh>
      ))}
    </Canvas>
  );
}
export default ThreeBarChart;