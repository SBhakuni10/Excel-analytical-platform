import React from 'react';
import { Canvas } from '@react-three/fiber';

function ThreeScatterChart({ labels, values }) {
  return (
    <Canvas camera={{ position: [0, 0, 20] }}>
      <ambientLight />
      {labels.map((label, i) => (
        <mesh key={i} position={[label, values[i], 0]}>
          <sphereGeometry args={[0.2, 32, 32]} />
          <meshStandardMaterial color={'#ff9800'} />
        </mesh>
      ))}
    </Canvas>
  );
}
export default ThreeScatterChart;