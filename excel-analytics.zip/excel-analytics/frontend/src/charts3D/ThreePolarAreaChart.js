import React from 'react';
import { Canvas } from '@react-three/fiber';

function ThreePolarAreaChart({ labels, values }) {
  return (
    <Canvas camera={{ position: [0, 0, 15] }}>
      <ambientLight />
      {values.map((val, idx) => (
        <mesh key={idx} position={[Math.cos(idx) * 3, Math.sin(idx) * 3, 0]}>
          <cylinderGeometry args={[0, val / 10, 1, 32]} />
          <meshStandardMaterial color={'#00bcd4'} />
        </mesh>
      ))}
    </Canvas>
  );
}
export default ThreePolarAreaChart;