// ✅ FILE: src/features/chartSlice.js
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  data: [],
  columns: [],
  xAxis: '',
  yAxis: '',
  chartType: 'Bar',
  chartMode: '2D',
};

const chartSlice = createSlice({
  name: 'chart',
  initialState,
  reducers: {
    setData: (state, action) => {
      state.data = action.payload;
    },
    setColumns: (state, action) => {
      state.columns = action.payload;
    },
    setXAxis: (state, action) => {
      state.xAxis = action.payload;
    },
    setYAxis: (state, action) => {
      state.yAxis = action.payload;
    },
    setChartType: (state, action) => {
      state.chartType = action.payload;
    },
    setChartMode: (state, action) => {
      state.chartMode = action.payload;
    },
    resetChart: () => initialState,
  },
});

export const {
  setData,
  setColumns,
  setXAxis,
  setYAxis,
  setChartType,
  setChartMode,
  resetChart,
} = chartSlice.actions;

export default chartSlice.reducer;
