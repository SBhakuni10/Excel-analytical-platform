// src/theme-init.js

const root = document.documentElement;

// Get saved theme or fallback to light
const theme = localStorage.getItem('theme') || 'light';

if (theme === 'dark') {
  root.classList.add('dark');
} else {
  root.classList.remove('dark');
}

// Apply shared global styles only once
const classesToAdd = [
  'transition-colors', 'duration-300',
  'bg-white', 'dark:bg-gray-900',
  'text-gray-900', 'dark:text-gray-100',
  'min-h-screen', 'flex', 'flex-col',
  'antialiased', 'font-sans', 'text-base', 'leading-relaxed'
];

// Filter and apply only if not already present
classesToAdd.forEach(cls => {
  if (!root.classList.contains(cls)) {
    root.classList.add(cls);
  }
});
