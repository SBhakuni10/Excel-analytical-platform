// ✅ FILE: src/app/store.js
import { configureStore } from '@reduxjs/toolkit';
import chartReducer from '../features/chartSlice';
import authReducer from '../features/authSlice';

const store = configureStore({
  reducer: {
    chart: chartReducer,
    auth: authReducer,
  },
});

export default store;
