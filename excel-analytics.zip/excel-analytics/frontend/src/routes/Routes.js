// ✅ FILE: src/routes/AppRoutes.js
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';

import LoginPage from '../pages/LoginPage';
import RegisterPage from '../pages/RegisterPage';
import UserDashboard from '../pages/user/UserDashboard';
import AdminDashboard from '../pages/admin/AdminDashboard';
import UserProfile from '../pages/user/UserProfile';
import ChangePassword from '../pages/user/ChangePassword';
import AdminProfile from '../pages/admin/AdminProfile';
import AdminChangePassword from '../pages/admin/AdminChangePassword';

// ✅ Protected Route component
function ProtectedRoute({ role, children }) {
  const { isAuthenticated, user } = useSelector((state) => state.auth);
  const localUser = JSON.parse(localStorage.getItem('user'));
  const finalUser = user || localUser;

  // not logged in
  if (!finalUser) return <Navigate to="/login" replace />;
  // role mismatch
  if (role && finalUser.role !== role) return <Navigate to="/login" replace />;

  return children;
}

function AppRoutes() {
  return (
    <Routes>
      {/* 🔓 Public Routes */}
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />

      {/* 🔐 User Protected Routes */}
      <Route
        path="/user-dashboard/*"
        element={
          <ProtectedRoute role="user">
            <UserDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/profile"
        element={
          <ProtectedRoute role="user">
            <UserProfile />
          </ProtectedRoute>
        }
      />
      <Route
        path="/change-password"
        element={
          <ProtectedRoute role="user">
            <ChangePassword />
          </ProtectedRoute>
        }
      />

      {/* 🔐 Admin Protected Routes */}
      <Route
        path="/admin-dashboard/*"
        element={
          <ProtectedRoute role="admin">
            <AdminDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin/profile"
        element={
          <ProtectedRoute role="admin">
            <AdminProfile />
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin/change-password"
        element={
          <ProtectedRoute role="admin">
            <AdminChangePassword />
          </ProtectedRoute>
        }
      />

      {/* 🚫 Fallback Route */}
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}

export default AppRoutes;
