import React from 'react';
import { Line } from 'react-chartjs-2';

function LineChart2D({ labels, values }) {
  const chartData = {
    labels,
    datasets: [{ label: 'Line Chart', data: values, fill: false, borderColor: '#42a5f5' }]
  };
  return <Line data={chartData} />;
}
export default LineChart2D;
