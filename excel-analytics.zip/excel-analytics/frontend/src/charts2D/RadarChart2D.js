import React from 'react';
import { Radar } from 'react-chartjs-2';

function RadarChart2D({ labels, values }) {
  const chartData = {
    labels,
    datasets: [{ label: 'Radar Chart', data: values, backgroundColor: 'rgba(179,181,198,0.2)', borderColor: 'rgba(179,181,198,1)', pointBackgroundColor: 'rgba(179,181,198,1)' }]
  };
  return <Radar data={chartData} />;
}
export default RadarChart2D;
