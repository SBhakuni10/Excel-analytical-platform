import React from 'react';
import { Bar } from 'react-chartjs-2';

function BarChart2D({ labels, values }) {
  const chartData = {
    labels,
    datasets: [
      {
        label: 'Bar Chart',
        data: values,
        backgroundColor: 'rgba(54, 162, 235, 0.6)'
      }
    ]
  };

  return <Bar data={chartData} />;
}

export default BarChart2D;
