import React from 'react';
import { Scatter } from 'react-chartjs-2';

function ScatterChart2D({ labels, values }) {
  const chartData = {
    datasets: [{ label: 'Scatter Chart', data: labels.map((l, i) => ({ x: l, y: values[i] })), backgroundColor: '#4bc0c0' }]
  };
  return <Scatter data={chartData} />;
}
export default ScatterChart2D;
