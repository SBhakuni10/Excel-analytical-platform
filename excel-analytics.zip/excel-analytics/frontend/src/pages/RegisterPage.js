import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { IconButton } from '@mui/material';
import { Visibility, VisibilityOff } from '@mui/icons-material';

function RegisterPage() {
  const [form, setForm] = useState({
    username: '',
    password: '',
    role: 'user',
    name: '',
    email: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value.trim() });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const existing = JSON.parse(localStorage.getItem('users')) || [];

    const alreadyExists = existing.find(
      (u) =>
        u.username.toLowerCase() === form.username.toLowerCase() ||
        u.email.toLowerCase() === form.email.toLowerCase()
    );

    if (alreadyExists) {
      alert('❌ Username or Email already exists!');
      return;
    }

    const newUser = {
      ...form,
      username: form.username.toLowerCase(),
      email: form.email.toLowerCase(),
    };

    const updatedUsers = [...existing, newUser];
    localStorage.setItem('users', JSON.stringify(updatedUsers));
    localStorage.setItem('user', JSON.stringify(newUser));

    alert('✅ Registered and logged in successfully!');
    navigate(newUser.role === 'admin' ? '/admin-dashboard' : '/user-dashboard');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-200 to-blue-400">
      <form
        onSubmit={handleSubmit}
        autoComplete="off"
        className="bg-white text-gray-800 p-10 rounded-2xl shadow-2xl w-full max-w-md"
      >
        <h2 className="text-3xl font-bold text-center text-green-700 mb-6">Register</h2>

        <input
          type="text"
          name="name"
          placeholder="Full Name"
          value={form.name}
          onChange={handleChange}
          className="w-full px-4 py-3 mb-4 border border-green-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400"
          required
        />

        <input
          type="email"
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          className="w-full px-4 py-3 mb-4 border border-green-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400"
          required
        />

        <input
          type="text"
          name="username"
          placeholder="Username"
          value={form.username}
          onChange={handleChange}
          className="w-full px-4 py-3 mb-4 border border-green-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400"
          required
        />

        <div className="relative mb-4">
          <input
            type={showPassword ? 'text' : 'password'}
            name="password"
            placeholder="Password"
            value={form.password}
            onChange={handleChange}
            className="w-full px-4 py-3 pr-12 border border-green-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400"
            required
          />
          <IconButton
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="!absolute top-1/2 right-3 -translate-y-1/2"
            size="small"
          >
            {showPassword ? <VisibilityOff /> : <Visibility />}
          </IconButton>
        </div>

        <select
          name="role"
          value={form.role}
          onChange={handleChange}
          className="w-full px-4 py-3 mb-6 border border-green-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400"
        >
          <option value="user">User</option>
          <option value="admin">Admin</option>
        </select>

        <button
          type="submit"
          className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-xl font-semibold transition"
        >
          Register
        </button>

        <p className="text-sm mt-4 text-center">
          Already have an account?{' '}
          <a className="text-green-800 font-medium hover:underline" href="/login">
            Login
          </a>
        </p>
      </form>
    </div>
  );
}

export default RegisterPage;
