import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

import Sidebar from '../../components/Sidebar';
import Header from '../../components/Header';

import ChartDisplay from '../../components/ChartDisplay';
import AIInsights from '../../components/AIInsights';
import History from '../../components/History';
import RegisteredUsers from './RegisteredUsers';
import AdminHistory from './AdminHistory';
import AdminOverview from './AdminOverview';
import PlatformAnalytics from './PlatformAnalytics';
import AdminSettings from './AdminSettings';

function AdminDashboard() {
  const storedUser = JSON.parse(localStorage.getItem('user'));

  const handleLogout = () => {
    localStorage.removeItem('user');
    window.location.href = '/login';
  };

  return (
    <div className="bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 min-h-screen transition-colors duration-300">
      {/* Sidebar */}
      <Sidebar />

      {/* Main content */}
      <div className="md:ml-64 flex flex-col min-h-screen">
        <Header
          title="Admin Dashboard"
          onLogout={handleLogout}
          profileRoute="/admin/profile"
          changePasswordRoute="/admin/change-password"
          userInitial={storedUser?.name?.charAt(0).toUpperCase() || 'A'}
        />

        <main className="flex-1 p-6 bg-white dark:bg-gray-900 transition-colors duration-300">
          <Routes>
            <Route path="" element={<AdminOverview />} />
            <Route path="chart-display" element={<ChartDisplay />} />
            <Route path="ai-insights" element={<AIInsights />} />
            <Route path="history" element={<History />} />
            <Route path="admin-history" element={<AdminHistory />} />
            <Route path="users" element={<RegisteredUsers />} />
            <Route path="overview" element={<AdminOverview />} />
            <Route path="analytics" element={<PlatformAnalytics />} />
            <Route path="settings" element={<AdminSettings />} />
            <Route path="*" element={<Navigate to="" />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

export default AdminDashboard;
