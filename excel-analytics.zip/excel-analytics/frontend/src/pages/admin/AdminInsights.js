// ✅ FILE: src/pages/admin/AdminInsights.js
import React, { useState, useEffect } from 'react';

function AdminInsights() {
  const [insight, setInsight] = useState('');

  useEffect(() => {
    const saved = localStorage.getItem('admin_ai_insight');
    if (saved) setInsight(saved);
  }, []);

  const handleChange = (e) => {
    setInsight(e.target.value);
    localStorage.setItem('admin_ai_insight', e.target.value);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h2 className="text-xl font-semibold mb-4">Admin AI Insights</h2>
      <textarea
        value={insight}
        onChange={handleChange}
        rows="4"
        className="border border-gray-300 rounded px-3 py-2 w-full focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Type or summarize key data insights for the team..."
      />
    </div>
  );
}

export default AdminInsights;
