import React, { useEffect, useState } from 'react';
import { Line } from 'react-chartjs-2';
import 'chart.js/auto';

function PlatformAnalytics() {
  const [chartData, setChartData] = useState({});

  useEffect(() => {
    const history = JSON.parse(localStorage.getItem('upload_history') || '[]');
    const uploadsByDate = {};

    history.forEach(file => {
      const date = file.uploadDate?.split('T')[0]; // YYYY-MM-DD
      if (date) {
        uploadsByDate[date] = (uploadsByDate[date] || 0) + 1;
      }
    });

    const sortedDates = Object.keys(uploadsByDate).sort();
    const uploadCounts = sortedDates.map(date => uploadsByDate[date]);

    setChartData({
      labels: sortedDates,
      datasets: [
        {
          label: 'Upload Growth Over Time',
          data: uploadCounts,
          borderColor: '#60A5FA',
          backgroundColor: 'rgba(96, 165, 250, 0.2)',
          tension: 0.3,
        },
      ],
    });
  }, []);

  return (
    <div className="bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 p-6 rounded-lg shadow transition-colors duration-300">
      <h2 className="text-xl font-bold text-blue-700 dark:text-blue-400 mb-4">
        📈 Growth Analytics
      </h2>
      {chartData.labels?.length ? (
        <Line
          data={chartData}
          options={{
            responsive: true,
            plugins: {
              legend: {
                labels: {
                  color: '#ccc', // Default for dark; will be overridden
                },
              },
            },
            scales: {
              x: {
                ticks: {
                  color: '#ccc', // X-axis label color
                },
                grid: {
                  color: 'rgba(200,200,200,0.1)',
                },
              },
              y: {
                ticks: {
                  color: '#ccc', // Y-axis label color
                },
                grid: {
                  color: 'rgba(200,200,200,0.1)',
                },
              },
            },
          }}
        />
      ) : (
        <p className="text-gray-600 dark:text-gray-300">No growth data available.</p>
      )}
    </div>
  );
}

export default PlatformAnalytics;
