import React, { useEffect, useState } from 'react';

function RegisteredUsers() {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ name: '', email: '' });
  const [editIndex, setEditIndex] = useState(null);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    const data = localStorage.getItem('registered_users');
    if (data) setUsers(JSON.parse(data));
  }, []);

  const saveUsers = (updated) => {
    setUsers(updated);
    localStorage.setItem('registered_users', JSON.stringify(updated));
  };

  const handleDelete = (index) => {
    const updated = [...users];
    updated.splice(index, 1);
    saveUsers(updated);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.email) return alert('Please fill in all fields.');
    const updated = [...users];
    if (editIndex !== null) {
      updated[editIndex] = form;
    } else {
      updated.push(form);
    }
    saveUsers(updated);
    setForm({ name: '', email: '' });
    setEditIndex(null);
    setShowForm(false);
  };

  const handleEdit = (index) => {
    setForm(users[index]);
    setEditIndex(index);
    setShowForm(true);
  };

  return (
    <div className="bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 p-6 rounded-xl shadow transition-all">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">👥 Registered Users</h2>
        <button
          onClick={() => {
            setForm({ name: '', email: '' });
            setEditIndex(null);
            setShowForm(true);
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm"
        >
          ➕ Add User
        </button>
      </div>

      {users.length === 0 ? (
        <p className="text-gray-500 dark:text-gray-300">No users found.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left border-collapse">
            <thead>
              <tr className="bg-gray-100 dark:bg-gray-700">
                <th className="py-2 px-4 border dark:border-gray-600">Name</th>
                <th className="py-2 px-4 border dark:border-gray-600">Email</th>
                <th className="py-2 px-4 border dark:border-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user, i) => (
                <tr key={i} className="border-t dark:border-gray-700">
                  <td className="py-2 px-4 border dark:border-gray-700">{user.name}</td>
                  <td className="py-2 px-4 border dark:border-gray-700">{user.email}</td>
                  <td className="py-2 px-4 border dark:border-gray-700 space-x-2">
                    <button
                      onClick={() => handleEdit(i)}
                      className="bg-yellow-500 hover:bg-yellow-600 text-white px-2 py-1 rounded text-xs"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(i)}
                      className="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded text-xs"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showForm && (
        <div className="mt-6 bg-gray-50 dark:bg-gray-800 border border-blue-200 dark:border-gray-600 p-4 rounded-lg shadow-inner">
          <h3 className="text-lg font-semibold mb-2">
            {editIndex !== null ? '✏️ Edit User' : '➕ Add User'}
          </h3>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input
              type="text"
              placeholder="Name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
            />
            <input
              type="email"
              placeholder="Email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
            />
            <div className="col-span-2 flex gap-2">
              <button
                type="submit"
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded"
              >
                {editIndex !== null ? 'Update' : 'Add'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setForm({ name: '', email: '' });
                  setEditIndex(null);
                }}
                className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

export default RegisteredUsers;
