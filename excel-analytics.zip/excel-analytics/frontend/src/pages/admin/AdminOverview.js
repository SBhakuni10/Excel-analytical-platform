import React, { useEffect, useState } from 'react';

function AdminOverview() {
  const [totalFiles, setTotalFiles] = useState(0);
  const [totalUsers, setTotalUsers] = useState(0);
  const [recentInsight, setRecentInsight] = useState('');

  useEffect(() => {
    const files = JSON.parse(localStorage.getItem('upload_history') || '[]');
    const users = JSON.parse(localStorage.getItem('registered_users') || '[]');
    const insight = localStorage.getItem('admin_ai_insight') || '';

    setTotalFiles(files.length);
    setTotalUsers(users.length);
    setRecentInsight(insight);
  }, []);

  return (
    <div className="bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 p-6 rounded-lg shadow transition-colors duration-300">
      <h2 className="text-2xl font-bold text-blue-700 dark:text-blue-400 mb-4">📊 Admin Analytics Overview</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-blue-100 dark:bg-blue-900 p-4 rounded-lg text-center shadow-sm">
          <h3 className="text-lg font-semibold">Total Files</h3>
          <p className="text-3xl font-bold text-blue-800 dark:text-blue-300">{totalFiles}</p>
        </div>
        <div className="bg-green-100 dark:bg-green-900 p-4 rounded-lg text-center shadow-sm">
          <h3 className="text-lg font-semibold">Total Users</h3>
          <p className="text-3xl font-bold text-green-800 dark:text-green-300">{totalUsers}</p>
        </div>
        <div className="bg-yellow-100 dark:bg-yellow-900 p-4 rounded-lg shadow-sm">
          <h3 className="text-lg font-semibold mb-2">Latest AI Insight</h3>
          <p className="text-gray-700 dark:text-gray-200 text-sm">
            {recentInsight || 'No insights yet.'}
          </p>
        </div>
      </div>
    </div>
  );
}

export default AdminOverview;
