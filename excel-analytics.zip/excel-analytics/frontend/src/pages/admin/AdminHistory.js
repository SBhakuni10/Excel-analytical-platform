// ✅ FILE: src/pages/admin/AdminDashboard.js
import React from 'react';
import { Routes, Route, Navigate, useNavigate } from 'react-router-dom';

import Sidebar from '../../components/Sidebar';
import Header from '../../components/Header';

import UploadExcel from '../../components/UploadExcel';
import ChartConfig from '../../components/ChartConfig';
import ChartDisplay from '../../components/ChartDisplay';
import AIInsights from '../../components/AIInsights';
import History from '../../components/History';
import RegisteredUsers from './RegisteredUsers';
import AdminHistory from './AdminHistory';

function AdminDashboard() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <Header title="Admin Dashboard" onLogout={handleLogout} />
        <main className="flex-1 p-6 bg-gradient-to-b from-gray-50 to-gray-200">
          <Routes>
            <Route
              path=""
              element={
                <div className="p-6 bg-white rounded-xl shadow text-blue-800 text-xl font-semibold">
                  📊 Welcome Admin! Monitor registered users, uploads, and analytics.
                </div>
              }
            />
            <Route path="upload-excel" element={<UploadExcel />} />
            <Route path="chart-config" element={<ChartConfig />} />
            <Route path="chart-display" element={<ChartDisplay />} />
            <Route path="ai-insights" element={<AIInsights />} />
            <Route path="history" element={<History />} />
            <Route path="admin-history" element={<AdminHistory />} />
            <Route path="users" element={<RegisteredUsers />} />
            <Route path="*" element={<Navigate to="" />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

export default AdminDashboard;
