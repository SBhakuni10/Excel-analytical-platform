// ✅ FILE: src/pages/user/Settings.js
import React, { useContext } from 'react';
import { ThemeContext } from '../../context/ThemeContext';
import { Moon, Sun } from 'lucide-react';

function Settings() {
  const { darkMode, toggleTheme } = useContext(ThemeContext);

  return (
    <div className="max-w-3xl mx-auto p-8 mt-12 bg-white dark:bg-gray-800 rounded-2xl shadow-xl transition-all duration-300">
      <h2 className="text-3xl font-bold text-blue-700 dark:text-yellow-400 mb-6 flex items-center gap-2">
        ⚙️Settings
      </h2>

      <div className="border-t border-gray-300 dark:border-gray-600 pt-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {darkMode ? (
              <Moon className="w-5 h-5 text-yellow-400" />
            ) : (
              <Sun className="w-5 h-5 text-yellow-600" />
            )}
            <span className="text-lg font-medium text-gray-900 dark:text-gray-100">
              Enable Dark Mode
            </span>
          </div>

          <label className="inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={darkMode}
              onChange={toggleTheme}
              className="sr-only peer"
            />
            <div className="w-12 h-6 bg-gray-300 dark:bg-gray-700 rounded-full peer peer-checked:bg-blue-600 relative transition">
              <div className="w-5 h-5 bg-white rounded-full shadow absolute left-0.5 top-0.5 peer-checked:translate-x-full transition-transform" />
            </div>
          </label>
        </div>
      </div>

    
    </div>
  );
}

export default Settings;
