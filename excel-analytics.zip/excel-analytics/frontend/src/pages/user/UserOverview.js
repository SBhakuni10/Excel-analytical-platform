import React, { useEffect, useState } from 'react';

function UserOverview() {
  const [fileCount, setFileCount] = useState(0);
  const [lastChart, setLastChart] = useState('');
  const [lastInsight, setLastInsight] = useState('');

  useEffect(() => {
    const history = JSON.parse(localStorage.getItem('upload_history') || '[]');
    const chart = localStorage.getItem('last_chart_type') || 'N/A';
    const insight = localStorage.getItem('ai_insight') || 'No insights available.';

    setFileCount(history.length);
    setLastChart(chart);
    setLastInsight(insight);
  }, []);

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md text-gray-800 dark:text-gray-100">
      <h2 className="text-2xl font-bold text-blue-700 dark:text-blue-400 mb-6">
        📊 Your Dashboard Summary
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-blue-100 dark:bg-blue-900/30 p-4 rounded-lg text-center">
          <h3 className="text-lg font-semibold">Total Uploads</h3>
          <p className="text-3xl font-bold text-blue-900 dark:text-blue-200">{fileCount}</p>
        </div>

        <div className="bg-purple-100 dark:bg-purple-900/30 p-4 rounded-lg text-center">
          <h3 className="text-lg font-semibold">Last Chart Type</h3>
          <p className="text-xl font-medium text-purple-800 dark:text-purple-200">{lastChart}</p>
        </div>

        <div className="bg-yellow-100 dark:bg-yellow-800/40 p-4 rounded-lg">
          <h3 className="text-lg font-semibold mb-2">Latest Insight</h3>
          <p className="text-gray-700 dark:text-gray-200 text-sm">{lastInsight}</p>
        </div>
      </div>
    </div>
  );
}

export default UserOverview;
