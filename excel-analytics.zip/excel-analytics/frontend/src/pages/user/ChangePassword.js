import React, { useState } from 'react';

const ChangePassword = () => {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Changing password...', { currentPassword, newPassword });
    setSuccessMsg('✅ Password updated successfully!');
  };

  return (
    <div className="p-6 bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-100 rounded shadow max-w-xl mx-auto mt-10 transition-colors duration-300">
      <h2 className="text-2xl font-bold mb-4 text-blue-600 dark:text-blue-400">🔒 Change Password</h2>

      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="password"
          placeholder="Current Password"
          value={currentPassword}
          onChange={(e) => setCurrentPassword(e.target.value)}
          className="w-full p-3 border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          required
        />
        <input
          type="password"
          placeholder="New Password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          className="w-full p-3 border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          required
        />
        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-medium transition"
        >
          Change Password
        </button>
      </form>

      {successMsg && <p className="mt-4 text-green-600 dark:text-green-400">{successMsg}</p>}
    </div>
  );
};

export default ChangePassword;
