import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

import Sidebar from '../../components/Sidebar';
import Header from '../../components/Header';
import UploadExcel from '../../components/UploadExcel';
import ChartDisplay from '../../components/ChartDisplay';
import ChartConfig from '../../components/ChartConfig';
import AIInsights from '../../components/AIInsights';
import History from '../../components/History';
import UserOverview from './UserOverview';
import Settings from './Settings';

function UserDashboard() {
  const storedUser = JSON.parse(localStorage.getItem('user'));

  const handleLogout = () => {
    localStorage.removeItem('user');
    window.location.href = '/login';
  };

  return (
    <div className="bg-gray-100 dark:bg-gray-900 min-h-screen">
      {/* Sidebar */}
      <Sidebar />

      {/* Main content area */}
      <div className="md:ml-64 flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900">
        <Header
          title="User Dashboard"
          onLogout={handleLogout}
          profileRoute="/profile"
          changePasswordRoute="/change-password"
          avatarSrc=""
          userInitial={storedUser?.name?.charAt(0).toUpperCase() || 'U'}
        />

        <main className="flex-1 px-4 py-6 sm:px-6 md:px-8 lg:px-12 bg-gray-100 dark:bg-gray-800 text-black dark:text-white">
          <Routes>
            <Route path="" element={<UserOverview />} />
            <Route path="upload-excel" element={<UploadExcel />} />
            <Route path="chart-config" element={<ChartConfig />} />
            <Route path="chart-display" element={<ChartDisplay />} />
            <Route path="ai-insights" element={<AIInsights />} />
            <Route path="history" element={<History />} />
            <Route path="settings" element={<Settings />} />
            <Route path="*" element={<Navigate to="" />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

export default UserDashboard;
