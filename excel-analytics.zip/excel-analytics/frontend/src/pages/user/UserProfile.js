import React from 'react';
import { useSelector } from 'react-redux';
import { User } from 'lucide-react';

const UserProfile = () => {
  const user = useSelector((state) => state.auth.user);

  return (
    <div className="max-w-3xl mx-auto p-6 mt-10 bg-white dark:bg-gray-800 rounded-xl shadow-md text-gray-800 dark:text-gray-100 transition-colors duration-300">
      <h2 className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-6 flex items-center gap-2">
        <User className="w-6 h-6" />
        User Profile
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Full Name */}
        <div className="flex flex-col space-y-1">
          <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">Full Name</label>
          <div className="px-4 py-2 bg-gray-100 dark:bg-gray-700 rounded-md shadow-sm">
            {user?.name || 'Not available'}
          </div>
        </div>

        {/* Email Address */}
        <div className="flex flex-col space-y-1">
          <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">Email Address</label>
          <div className="px-4 py-2 bg-gray-100 dark:bg-gray-700 rounded-md shadow-sm">
            {user?.email || 'Not available'}
          </div>
        </div>

        {/* Username */}
        <div className="flex flex-col space-y-1">
          <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">Username</label>
          <div className="px-4 py-2 bg-gray-100 dark:bg-gray-700 rounded-md shadow-sm">
            {user?.username || 'Not available'}
          </div>
        </div>

        {/* Role */}
        <div className="flex flex-col space-y-1">
          <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">Role</label>
          <div className="px-4 py-2 bg-gray-100 dark:bg-gray-700 rounded-md shadow-sm">
            {user?.role || 'Not available'}
          </div>
        </div>
      </div>

      <div className="mt-8 text-center">
        <button
          onClick={() => alert('🛠️ Edit profile functionality coming soon!')}
          className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition"
        >
          ✏️ Edit Profile
        </button>
      </div>
    </div>
  );
};

export default UserProfile;
