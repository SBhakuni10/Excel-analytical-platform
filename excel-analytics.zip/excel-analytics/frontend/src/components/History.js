import React, { useEffect, useState } from 'react';

function History() {
  const [uploads, setUploads] = useState([]);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem('upload_history')) || [];
    setUploads(saved);
  }, []);

  const handleClear = () => {
    if (window.confirm('Are you sure you want to clear upload history?')) {
      localStorage.removeItem('upload_history');
      setUploads([]);
    }
  };

  return (
    <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-md text-gray-800 dark:text-gray-100">
      <h2 className="text-2xl font-bold text-blue-700 dark:text-blue-400 mb-4">📜 Upload History</h2>

      {uploads.length === 0 ? (
        <p className="text-gray-500 dark:text-gray-300">No uploads found.</p>
      ) : (
        <div>
          <ul className="list-disc pl-5 space-y-2 text-blue-800 dark:text-blue-300">
            {uploads.map((file, idx) => (
              <li key={idx}>{file.name} — {file.date}</li>
            ))}
          </ul>

          <button
            onClick={handleClear}
            className="mt-4 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-xl transition"
          >
            Clear History
          </button>
        </div>
      )}
    </div>
  );
}

export default History;
