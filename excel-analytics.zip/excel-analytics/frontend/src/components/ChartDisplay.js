import React, { useRef } from 'react';
import { useSelector } from 'react-redux';
import { downloadAsPNG, downloadAsPDF } from '../utils/exportChart';

// 2D Charts
import BarChart2D from '../charts2D/BarChart2D';
import PieChart2D from '../charts2D/PieChart2D';
import DoughnutChart2D from '../charts2D/DoughnutChart2D';
import LineChart2D from '../charts2D/LineChart2D';
import RadarChart2D from '../charts2D/RadarChart2D';
import PolarAreaChart2D from '../charts2D/PolarAreaChart2D';
import ScatterChart2D from '../charts2D/ScatterChart2D';

// 3D Charts
import ThreeBarChart from '../charts3D/ThreeBarChart';
import ThreePieChart from '../charts3D/ThreePieChart';
import ThreeLineChart from '../charts3D/ThreeLineChart';
import ThreeRadarChart from '../charts3D/ThreeRadarChart';
import ThreePolarAreaChart from '../charts3D/ThreePolarAreaChart';
import ThreeScatterChart from '../charts3D/ThreeScatterChart';

function ChartDisplay() {
  const chartRef = useRef();
  const { data, xAxis, yAxis, chartType, chartMode } = useSelector((state) => state.chart);

  if (!data || !xAxis || !yAxis || data.length === 0) {
    return (
      <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-md text-gray-800 dark:text-gray-100">
        <h2 className="text-2xl font-bold text-blue-700 dark:text-blue-400 mb-4">📈 Chart Output</h2>
        <p className="text-gray-600 dark:text-gray-300">
          ⚠️ Please upload Excel data and configure chart settings.
        </p>
      </div>
    );
  }

  const labels = data.map((row) => row[xAxis]);
  const values = data.map((row) => Number(row[yAxis]));

  const renderChart = () => {
    if (chartMode === '2D') {
      switch (chartType) {
        case 'Bar': return <BarChart2D labels={labels} values={values} />;
        case 'Pie': return <PieChart2D labels={labels} values={values} />;
        case 'Doughnut': return <DoughnutChart2D labels={labels} values={values} />;
        case 'Line': return <LineChart2D labels={labels} values={values} />;
        case 'Radar': return <RadarChart2D labels={labels} values={values} />;
        case 'PolarArea': return <PolarAreaChart2D labels={labels} values={values} />;
        case 'Scatter': return <ScatterChart2D labels={labels} values={values} />;
        default: return <p className="text-red-600 dark:text-red-400">🚫 2D chart type not supported: {chartType}</p>;
      }
    } else if (chartMode === '3D') {
      switch (chartType) {
        case 'Bar': return <ThreeBarChart labels={labels} values={values} />;
        case 'Pie': return <ThreePieChart labels={labels} values={values} />;
        case 'Line': return <ThreeLineChart labels={labels} values={values} />;
        case 'Radar': return <ThreeRadarChart labels={labels} values={values} />;
        case 'PolarArea': return <ThreePolarAreaChart labels={labels} values={values} />;
        case 'Scatter': return <ThreeScatterChart labels={labels} values={values} />;
        default: return <p className="text-red-600 dark:text-red-400">🚫 3D chart type not supported: {chartType}</p>;
      }
    } else {
      return <p className="text-red-600 dark:text-red-400">❗Invalid chart mode: {chartMode}</p>;
    }
  };

  return (
    <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-md text-gray-800 dark:text-gray-100">
      <h2 className="text-2xl font-bold text-blue-700 dark:text-blue-400 mb-4">📈 Chart Output</h2>

      <div
        ref={chartRef}
        id="chart-box"
        className="w-full h-[500px] overflow-hidden bg-white dark:bg-gray-700 rounded shadow"
      >
        {renderChart()}
      </div>

      <div className="flex gap-4 mt-6">
        <button
          onClick={() => downloadAsPNG(chartRef.current)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl shadow"
        >
          Export PNG
        </button>
        <button
          onClick={() => downloadAsPDF(chartRef.current)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl shadow"
        >
          Export PDF
        </button>
      </div>
    </div>
  );
}

export default ChartDisplay;
