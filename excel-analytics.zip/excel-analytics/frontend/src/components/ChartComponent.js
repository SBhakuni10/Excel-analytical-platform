import React, { useEffect, useRef } from 'react';
import {
  Bar,
  Line,
  Pie,
  Doughnut,
  Radar,
  PolarArea,
  Scatter,
  Bubble,
} from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  RadialLinearScale,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import * as THREE from 'three';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  RadialLinearScale,
  Title,
  Tooltip,
  Legend
);

function ChartComponent({ data = [], xAxis, yAxis, chartType = 'Bar', chartMode = '2D' }) {
  const threeRef = useRef();

  const labels = data?.map((row) => row[xAxis]) || [];
  const values = data?.map((row) => Number(row[yAxis]) || 0) || [];

  useEffect(() => {
    if (chartMode !== '3D' || !threeRef.current) return;

    // Cleanup
    while (threeRef.current.firstChild) {
      threeRef.current.removeChild(threeRef.current.firstChild);
    }

    const width = threeRef.current.clientWidth;
    const height = threeRef.current.clientHeight;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    threeRef.current.appendChild(renderer.domElement);

    const light = new THREE.PointLight(0xffffff, 1);
    light.position.set(10, 10, 10);
    scene.add(light);

    // === Add 3D Chart Geometry ===
    if (chartType === 'Bar') {
      values.forEach((value, i) => {
        const geometry = new THREE.BoxGeometry(1, 1, 1);
        const material = new THREE.MeshStandardMaterial({ color: 0x3f51b5 });
        const bar = new THREE.Mesh(geometry, material);
        bar.scale.y = value / 10;
        bar.position.x = i * 1.5;
        bar.position.y = bar.scale.y / 2;
        scene.add(bar);
      });
    } else if (chartType === 'Doughnut') {
      const geometry = new THREE.TorusGeometry(2, 0.6, 16, 100);
      const material = new THREE.MeshStandardMaterial({ color: 0x3f51b5 });
      const torus = new THREE.Mesh(geometry, material);
      scene.add(torus);
    }

    camera.position.z = 10;
    const animate = () => {
      requestAnimationFrame(animate);
      scene.rotation.y += 0.01;
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      while (threeRef.current.firstChild) {
        threeRef.current.removeChild(threeRef.current.firstChild);
      }
      renderer.dispose();
    };
  }, [chartType, chartMode, values]);

  if (!data || data.length === 0 || !xAxis || !yAxis) {
    return <div className="text-gray-600 p-4">⚠️ No data or axes selected.</div>;
  }

  const chartData = {
    labels,
    datasets: [
      {
        label: `${yAxis} vs ${xAxis}`,
        data: values,
        backgroundColor: 'rgba(63, 81, 181, 0.6)',
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: { position: 'top' },
      title: { display: true, text: `${chartType} Chart` },
    },
  };

  const chartMap = {
    Bar: <Bar data={chartData} options={options} />,
    Line: <Line data={chartData} options={options} />,
    Pie: <Pie data={chartData} options={options} />,
    Doughnut: <Doughnut data={chartData} options={options} />,
    Radar: <Radar data={chartData} options={options} />,
    PolarArea: <PolarArea data={chartData} options={options} />,
    Scatter: (
      <Scatter
        data={{
          datasets: [
            {
              label: `${yAxis} vs ${xAxis}`,
              data: values.map((v, i) => ({ x: i, y: v })),
              backgroundColor: 'rgba(63, 81, 181, 0.6)',
            },
          ],
        }}
        options={options}
      />
    ),
    Bubble: (
      <Bubble
        data={{
          datasets: [
            {
              label: `${yAxis} vs ${xAxis}`,
              data: values.map((v, i) => ({ x: i, y: v, r: 5 })),
              backgroundColor: 'rgba(63, 81, 181, 0.6)',
            },
          ],
        }}
        options={options}
      />
    ),
  };

  if (chartMode === '3D') {
    if (chartType !== 'Bar' && chartType !== 'Doughnut') {
      return (
        <div className="text-red-600 p-4">
          🚫 3D chart type not supported: <strong>{chartType}</strong>
        </div>
      );
    }
    return <div ref={threeRef} className="w-full h-[400px] bg-white rounded shadow" />;
  }

  return chartMap[chartType] || (
    <div className="text-red-600 p-4">❌ Invalid or unsupported chart type selected.</div>
  );
}

export default ChartComponent;
