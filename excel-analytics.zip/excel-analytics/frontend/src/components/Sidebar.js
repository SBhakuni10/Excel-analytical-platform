import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import {
  Home,
  Upload,
  BarChart2,
  Brain,
  History,
  Users,
  Activity,
  Menu,
  X,
  Settings
} from 'lucide-react';

function Sidebar() {
  const role = JSON.parse(localStorage.getItem('user'))?.role;
  const basePath = role === 'admin' ? '/admin-dashboard' : '/user-dashboard';
  const [isOpen, setIsOpen] = useState(false);

  const userLinks = [
    { name: 'Dashboard', path: '', icon: <Home size={18} /> },
    { name: 'Upload Excel', path: 'upload-excel', icon: <Upload size={18} /> },
    { name: 'Chart Config', path: 'chart-config', icon: <BarChart2 size={18} /> },
    { name: 'Chart Display', path: 'chart-display', icon: <Activity size={18} /> },
    { name: 'AI Insights', path: 'ai-insights', icon: <Brain size={18} /> },
    { name: 'History', path: 'history', icon: <History size={18} /> },
    { name: 'Settings', path: 'settings', icon: <Settings size={18} /> },
  ];

  const adminLinks = [
    { name: 'Dashboard', path: '', icon: <Home size={18} /> },
    { name: 'AI Reports', path: 'ai-insights', icon: <Brain size={18} /> },
    { name: 'Upload Logs', path: 'history', icon: <History size={18} /> },
    { name: 'Users', path: 'users', icon: <Users size={18} /> },
    { name: 'Analytics', path: 'analytics', icon: <Activity size={18} /> },
    { name: 'Settings', path: 'settings', icon: <Settings size={18} /> }, // ✅ Added for Admin
  ];

  const links = role === 'admin' ? adminLinks : userLinks;

  return (
    <>
      {/* Mobile Toggle */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="md:hidden fixed top-4 left-4 z-50 bg-blue-700 dark:bg-gray-800 text-white p-2 rounded-full shadow-lg"
      >
        {isOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Sidebar */}
      <aside
        className={`
          fixed top-0 left-0 h-full w-64 z-40 transition-transform shadow-xl
          ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0
          bg-gradient-to-b from-blue-800 to-blue-600 dark:from-gray-900 dark:to-gray-800
          text-white dark:text-gray-100
        `}
      >
        <div className="p-6">
          <h2 className="text-2xl font-bold mb-8">
            {role === 'admin' ? 'Admin' : 'User'} Panel
          </h2>

          <nav className="space-y-2">
            {links.map(({ name, path, icon }) => (
              <NavLink
                key={path}
                to={`${basePath}/${path}`}
                className={({ isActive }) =>
                  `flex items-center gap-3 py-2 px-4 rounded-xl font-medium transition-all
                  ${isActive
                    ? 'bg-blue-900 dark:bg-gray-700'
                    : 'hover:bg-blue-700 hover:text-white dark:hover:bg-gray-700 dark:hover:text-white'}`
                }
                onClick={() => setIsOpen(false)}
              >
                {icon}
                <span>{name}</span>
              </NavLink>
            ))}
          </nav>
        </div>
      </aside>
    </>
  );
}

export default Sidebar;
