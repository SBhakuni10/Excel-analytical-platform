import React, { useState } from 'react';
import axios from 'axios';

function AIInsights() {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAskQuestion = async () => {
    const apiKey = process.env.REACT_APP_OPENAI_API_KEY;

    if (!apiKey) {
      setAnswer("❌ API key is missing. Please check your .env file.");
      return;
    }

    if (!question.trim()) {
      setAnswer("⚠️ Please enter a question.");
      return;
    }

    setLoading(true);
    setAnswer('');

    try {
      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-3.5-turbo',
          messages: [{ role: 'user', content: question }],
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apiKey}`,
          },
        }
      );

      const aiText = response.data.choices?.[0]?.message?.content;

      if (aiText) {
        setAnswer(aiText.trim());
      } else {
        setAnswer("⚠️ No response from AI. Try again.");
      }
    } catch (error) {
      console.error("Axios/OpenAI Error:", error);
      setAnswer("❌ Failed to fetch AI response: " + (error.response?.data?.error?.message || error.message));
    }

    setLoading(false);
  };

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow overflow-x-auto text-gray-800 dark:text-gray-100">
      <h2 className="text-xl font-bold text-blue-700 dark:text-blue-400 mb-4">🤖 AI Insights</h2>

      <textarea
        className="w-full p-3 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-100 rounded mb-3 focus:outline-none focus:ring-2 focus:ring-blue-400 dark:focus:ring-blue-500"
        rows={4}
        placeholder="Ask a question about your data or anything..."
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
        disabled={loading}
      />

      <button
        onClick={handleAskQuestion}
        disabled={loading}
        className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded disabled:opacity-50"
      >
        {loading ? 'Thinking...' : 'Ask AI'}
      </button>

      {answer && (
        <div className="mt-4 p-4 bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded">
          <h3 className="font-semibold text-gray-700 dark:text-gray-200 mb-2">AI Response:</h3>
          <p className="whitespace-pre-line">{answer}</p>
        </div>
      )}
    </div>
  );
}

export default AIInsights;
