import React, { useEffect, useState } from 'react';
import * as XLSX from 'xlsx';
import { useDispatch } from 'react-redux';
import { setData, setColumns } from '../features/chartSlice';
import { useNavigate } from 'react-router-dom';

function UploadExcel() {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [lastFile, setLastFile] = useState(() => {
    return JSON.parse(localStorage.getItem('last_uploaded_file') || 'null');
  });

  useEffect(() => {
    if (lastFile && lastFile.data && lastFile.columns) {
      dispatch(setData(lastFile.data));
      dispatch(setColumns(lastFile.columns));
    }
  }, [lastFile, dispatch]);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const jsonData = XLSX.utils.sheet_to_json(ws, { defval: '' });

        if (jsonData.length === 0) throw new Error('Sheet is empty or invalid');

        const columns = Object.keys(jsonData[0]);
        dispatch(setData(jsonData));
        dispatch(setColumns(columns));

        const history = JSON.parse(localStorage.getItem('upload_history') || '[]');
        history.push({ name: file.name, date: new Date().toLocaleString() });
        localStorage.setItem('upload_history', JSON.stringify(history));

        const fileState = { name: file.name, data: jsonData, columns };
        localStorage.setItem('last_uploaded_file', JSON.stringify(fileState));
        setLastFile(fileState);

        alert(`✅ ${file.name} uploaded successfully!`);
        navigate('/user-dashboard/chart-config');
      } catch (error) {
        alert(`❌ Failed to parse file: ${error.message}`);
      }
    };
    reader.readAsBinaryString(file);
  };

  const clearLastUpload = () => {
    localStorage.removeItem('last_uploaded_file');
    setLastFile(null);
    alert('Previous upload cleared. You can upload a new file now.');
  };

  return (
    <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-md text-gray-800 dark:text-gray-100">
      <h2 className="text-2xl font-bold text-blue-700 dark:text-blue-400 mb-4">
        📁 Upload Excel File
      </h2>

      {lastFile ? (
        <div className="bg-blue-50 dark:bg-gray-700 border border-blue-300 dark:border-gray-600 p-4 rounded-xl mb-6 text-blue-700 dark:text-blue-200 flex justify-between items-center">
          <div>
            <p className="font-semibold">📄 Last uploaded file:</p>
            <p>{lastFile.name}</p>
          </div>
          <button
            onClick={clearLastUpload}
            className="text-red-500 font-bold hover:text-red-700 dark:hover:text-red-400"
            title="Clear uploaded file"
          >
            ❌
          </button>
        </div>
      ) : (
        <label className="block cursor-pointer border-2 border-dashed border-blue-400 dark:border-gray-600 rounded-xl p-6 text-center text-blue-600 dark:text-blue-300 hover:bg-blue-50 dark:hover:bg-gray-700 transition">
          <input
            type="file"
            accept=".xlsx, .xls"
            onChange={handleFileUpload}
            className="hidden"
          />
          Click or drag file to upload
        </label>
      )}
    </div>
  );
}

export default UploadExcel;

