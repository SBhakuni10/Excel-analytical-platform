import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {  User, LogOut, Lock } from 'lucide-react';

function Header({ title, onLogout, profileRoute, changePasswordRoute, avatarSrc, userInitial = 'U' }) {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="flex items-center justify-between px-6 py-4 bg-white dark:bg-gray-800 shadow-md relative z-10">
      <h1 className="text-xl font-semibold text-gray-900 dark:text-white">{title}</h1>

      <div className="relative">
        <button
          className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {avatarSrc ? (
            <img src={avatarSrc} alt="avatar" className="rounded-full w-full h-full object-cover" />
          ) : (
            userInitial
          )}
        </button>

        {menuOpen && (
          <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-md shadow-lg z-20">
            <button
              className="w-full flex items-center px-4 py-2 text-sm text-gray-700 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-600"
              onClick={() => {
                navigate(profileRoute);
                setMenuOpen(false);
              }}
            >
              <User size={16} className="mr-2" />
              View Profile
            </button>

            <button
              className="w-full flex items-center px-4 py-2 text-sm text-gray-700 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-600"
              onClick={() => {
                navigate(changePasswordRoute);
                setMenuOpen(false);
              }}
            >
              <Lock size={16} className="mr-2" />
              Change Password
            </button>

            <button
              className="w-full flex items-center px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-100 dark:hover:bg-gray-600"
              onClick={() => {
                setMenuOpen(false);
                onLogout(); // This should navigate and clear session
              }}
            >
              <LogOut size={16} className="mr-2" />
              Logout
            </button>
          </div>
        )}
      </div>
    </header>
  );
}

export default Header;
